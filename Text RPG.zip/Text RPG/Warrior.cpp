#include "Warrior.h"
#include "Monster.h"
#include <iostream>

Warrior::Warrior(const std::string& name, const int stat[])
    : Player(name, stat)
{
    job = "����";
    def += 30;
}

void Warrior::attack(Monster* monster)
{
    (void)monster;

    std::cout << name << "��(��) ���� �ֵθ���!" << std::endl;
}