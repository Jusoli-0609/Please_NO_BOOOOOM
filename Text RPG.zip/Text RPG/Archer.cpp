#include "Archer.h"
#include <string>
#include <iostream>

Archer::Archer(std::string name, const int stat[])
    : Player(name, stat)
{
    job = "�ü�";
    hp += 30;
}

void Archer::attack(Monster* monster)
{
    std::cout
        << name
        << "�� ȭ���� �߻��ߴ�!"
        << std::endl;
}