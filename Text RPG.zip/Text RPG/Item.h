﻿#pragma once
#include <string>
#include <iostream>

class Player;
class Monster;
class Item
{
public:
    std::string _Item_Name;
    int _Item_Price=0;
    int _Item_Count=0;
    int _Item_Weight=0;
    std::string _Item_Ascii_Art;
    std::string _Item_Description;
    bool _Item_Type_Usable=false;
    bool _Item_Type_Wearable=false;
    bool _Need_Item_Reverse_Effect=false;
    bool _Need_Reverse_Effect_Of_Attack_Potion_Buff = false;
    void Print_Info() const;//1.아이템 정보 내보내기
    bool Item_Effect(Player& player, Monster& monster);//2.아이템 효과 적용
    bool Item_Effect_Reverse(Player& player, Monster& monster);//3.아이템 효과 해제
    void Print_Ascii_Art() const;//4.아스키 아트 뭔말알?
 
   
};

